- Installer Flask
```
pip install flask
```

- Installer tensorflow
```
pip install tensorflow
```

- Installer PILLOW
```
pip install PILLOW
```
- Lancer l'exécution du Script flaskapp.py :

```
python flaskapp.py
```
